```mermaid
classDiagram
    class Country["国"] { schema:name; world:nameJa; world:region; world:regionJa }
    class Observation["年ごとの記録"] { world:year; world:population; world:lifeExpectancy; world:fertility }
    Observation --> Country : world:ofCountry
```
